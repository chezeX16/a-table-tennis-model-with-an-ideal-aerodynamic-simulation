"""
Table Tennis Aerodynamic Simulation Engine.
"""

from .constants import (
    BALL_MASS, BALL_RADIUS, BALL_DIAMETER, BALL_AREA, BALL_INERTIA,
    TABLE_LENGTH, TABLE_WIDTH, TABLE_HEIGHT_ABOVE_FLOOR,
    NET_HEIGHT, TABLE_COR_NORMAL, TABLE_FRICTION_MU
)
from .aerodynamics import (
    AerodynamicModel, calculate_air_density, calculate_dynamic_viscosity,
    calculate_drag_coefficient, calculate_lift_coefficient
)
from .table_collision import (
    CollisionEvent, is_on_table_surface, which_court,
    resolve_table_bounce, check_net_collision, resolve_net_collision
)
from .simulator import (
    TableTennisSimulator, SimulationResult, TrajectoryPoint
)
from .presets import STROKE_PRESETS, rpm_to_rad_s, rev_s_to_rad_s

__all__ = [
    'BALL_MASS', 'BALL_RADIUS', 'BALL_DIAMETER', 'BALL_AREA', 'BALL_INERTIA',
    'TABLE_LENGTH', 'TABLE_WIDTH', 'TABLE_HEIGHT_ABOVE_FLOOR',
    'NET_HEIGHT', 'TABLE_COR_NORMAL', 'TABLE_FRICTION_MU',
    'AerodynamicModel', 'calculate_air_density', 'calculate_dynamic_viscosity',
    'calculate_drag_coefficient', 'calculate_lift_coefficient',
    'CollisionEvent', 'is_on_table_surface', 'which_court',
    'resolve_table_bounce', 'check_net_collision', 'resolve_net_collision',
    'TableTennisSimulator', 'SimulationResult', 'TrajectoryPoint',
    'STROKE_PRESETS', 'rpm_to_rad_s', 'rev_s_to_rad_s'
]
