"""
High-Fidelity Aerodynamic Modeling for Table Tennis Balls.

Models:
1. Environmental atmosphere: Temperature, Pressure, Relative Humidity -> Air density rho.
2. Viscosity: Sutherland's law for dynamic viscosity mu(T).
3. Non-dimensional numbers:
   - Reynolds number: Re = (rho * v * D) / mu
   - Spin parameter: Sp = (R * omega) / v  (non-dimensional surface speed ratio)
4. Aerodynamic Drag Coefficient Cd(Re, Sp):
   - Baseline sphere drag Cd0(Re) in the subcritical laminar boundary layer regime (1e4 < Re < 1e5).
   - Spin-induced drag increment Cd_spin(Sp) from boundary layer separation displacement.
5. Aerodynamic Magnus Lift Coefficient Cl(Sp):
   - Asymmetric boundary layer circulation causing transverse lift.
   - Saturation model based on wind tunnel tests on 40+ celluloid and plastic balls.
6. Aerodynamic Viscous Spin Damping Torque tau_aero:
   - Skin friction and turbulent wake dissipation gradually decelerating ball rotation.
"""

import math
import numpy as np
from .constants import (
    BALL_MASS, BALL_RADIUS, BALL_DIAMETER, BALL_AREA, BALL_INERTIA,
    STANDARD_GRAVITY, STANDARD_PRESSURE, STANDARD_TEMP_C,
    R_DRY_AIR, R_VAPOR, SUTHERLAND_T0, SUTHERLAND_MU0, SUTHERLAND_S
)


def calculate_air_density(temp_c: float = STANDARD_TEMP_C,
                          pressure_pa: float = STANDARD_PRESSURE,
                          relative_humidity: float = 0.50) -> float:
    """
    Computes moist air density rho [kg/m^3] using the ideal gas law with water vapor partial pressure.
    
    Args:
        temp_c: Temperature in degrees Celsius
        pressure_pa: Atmospheric pressure in Pascals (e.g. 101325 Pa at sea level)
        relative_humidity: Relative humidity as fraction in [0, 1]
    
    Returns:
        Air density in kg/m^3 (~1.204 kg/m^3 at 20 C, 1 atm, 50% RH)
    """
    T_kelvin = temp_c + 273.15
    # Saturation vapor pressure of water (Tetens formula) in Pa
    P_sat = 610.78 * math.exp((17.27 * temp_c) / (temp_c + 237.3))
    # Actual vapor pressure
    P_v = relative_humidity * P_sat
    # Dry air partial pressure
    P_d = pressure_pa - P_v
    
    rho = (P_d / (R_DRY_AIR * T_kelvin)) + (P_v / (R_VAPOR * T_kelvin))
    return float(rho)


def calculate_dynamic_viscosity(temp_c: float = STANDARD_TEMP_C) -> float:
    """
    Computes dynamic viscosity mu [Pa*s] of air using Sutherland's formula.
    
    Args:
        temp_c: Temperature in degrees Celsius
    
    Returns:
        Dynamic viscosity in Pa*s (~1.81e-5 Pa*s at 20 C)
    """
    T = temp_c + 273.15
    mu = SUTHERLAND_MU0 * ((T / SUTHERLAND_T0) ** 1.5) * ((SUTHERLAND_T0 + SUTHERLAND_S) / (T + SUTHERLAND_S))
    return float(mu)


def calculate_drag_coefficient(reynolds: float, spin_param: float) -> float:
    """
    Empirical drag coefficient Cd(Re, Sp) for standard 40+ table tennis balls.
    
    In table tennis (Re ~ 10,000 - 80,000):
    - Non-spinning smooth sphere has Cd0 ~ 0.42 - 0.46.
    - Spin disrupts boundary layer symmetry, causing the separation point on the retreating
      side to move forward, widening the turbulent wake and significantly increasing drag.
    
    References:
    - Nakagawa et al. (2016): Aerodynamic characteristics of 40+ plastic table tennis balls.
    - Cross (2011), Bearman & Harvey (1976).
    """
    if reynolds < 1e-3:
        return 0.45
    
    # Base drag for a sphere in the subcritical regime (Clift & Gauvin correlation)
    cd0 = 0.44 + (24.0 / reynolds) + (6.0 / (1.0 + math.sqrt(reynolds)))
    # Clamp base drag to typical table tennis regime
    cd0 = max(0.40, min(0.50, cd0))
    
    # Spin-induced drag increment:
    # At Sp = 0, cd_spin = 0. At Sp = 1.0, cd increases by ~0.22 - 0.28.
    cd_spin = 0.32 * (spin_param ** 1.25) / (1.0 + 0.65 * (spin_param ** 1.25))
    
    return float(cd0 + cd_spin)


def calculate_lift_coefficient(spin_param: float) -> float:
    """
    Magnus lift coefficient Cl(Sp) as a function of spin parameter Sp = (R * omega) / v.
    
    Characteristics:
    - Linear increase for low spin: Cl ~ 1.4 * Sp
    - Boundary layer saturation at high spin parameter (Sp > 0.6 - 1.0)
    - Asymptotic upper limit Cl_max ~ 0.62 - 0.65 for smooth poly balls.
    
    Formula:
    Cl(Sp) = Cl_max * (1 - exp(-k * Sp))
    Matches wind tunnel data by Asai et al. and ITTF test benches.
    """
    if spin_param <= 1e-6:
        return 0.0
    
    cl_max = 0.63
    saturation_rate = 1.75
    return float(cl_max * (1.0 - math.exp(-saturation_rate * spin_param)))


def calculate_spin_damping_torque(omega_vec: np.ndarray,
                                  v_rel: float,
                                  rho: float,
                                  mu: float) -> np.ndarray:
    """
    Calculates the aerodynamic retarding torque [N*m] acting on the spinning ball.
    
    Skin friction and boundary layer shear cause spin decay over time.
    Experimentally, spin decreases by ~5-15% over a 0.5s table tennis flight.
    
    Torque consists of:
    1. Laminar Stokes rotational friction: tau_lam = -8 * pi * mu * R^3 * omega
    2. High-speed turbulent skin friction torque: tau_turb = -0.5 * rho * R^5 * Cm * |omega| * omega
    """
    omega_mag = np.linalg.norm(omega_vec)
    if omega_mag < 1e-6:
        return np.zeros(3)
    
    # Non-dimensional moment coefficient Cm (Dennis et al., 1980 for rotating spheres)
    # Re_rot = (rho * omega * R^2) / mu
    re_rot = (rho * omega_mag * (BALL_RADIUS ** 2)) / max(mu, 1e-7)
    if re_rot < 1.0:
        cm = 0.0
    else:
        cm = 0.045 / math.sqrt(max(1.0, re_rot))
    
    # Combined retarding torque opposite to omega direction
    t_lam = 8.0 * math.pi * mu * (BALL_RADIUS ** 3) * omega_vec
    t_turb = 0.5 * rho * (BALL_RADIUS ** 5) * cm * omega_mag * omega_vec
    
    tau_total = -(t_lam + t_turb)
    return tau_total


class AerodynamicModel:
    """
    Full aerodynamic evaluator for state derivatives:
    - Drag force F_D
    - Magnus force F_M
    - Gravity force F_g
    - Viscous spin torque tau_aero
    """
    def __init__(self,
                 temp_c: float = STANDARD_TEMP_C,
                 pressure_pa: float = STANDARD_PRESSURE,
                 relative_humidity: float = 0.50,
                 wind_velocity: np.ndarray = None,
                 enable_drag: bool = True,
                 enable_magnus: bool = True,
                 enable_spin_decay: bool = True):
        self.temp_c = temp_c
        self.pressure_pa = pressure_pa
        self.relative_humidity = relative_humidity
        self.wind_velocity = np.zeros(3) if wind_velocity is None else np.asarray(wind_velocity, dtype=float)
        
        self.enable_drag = enable_drag
        self.enable_magnus = enable_magnus
        self.enable_spin_decay = enable_spin_decay
        
        self.rho = calculate_air_density(temp_c, pressure_pa, relative_humidity)
        self.mu = calculate_dynamic_viscosity(temp_c)
        
    def evaluate_forces(self, vel: np.ndarray, omega: np.ndarray):
        """
        Calculates all forces and moments acting on the ball.
        
        Args:
            vel: Ball velocity vector in m/s [vx, vy, vz]
            omega: Angular velocity vector in rad/s [wx, wy, wz]
            
        Returns:
            dict containing:
                'f_total': Total force [N]
                'f_grav': Gravity force [N]
                'f_drag': Drag force [N]
                'f_magnus': Magnus force [N]
                'torque_aero': Spin damping torque [N*m]
                'cd': Drag coefficient
                'cl': Lift coefficient
                'reynolds': Reynolds number
                'spin_param': Non-dimensional spin parameter Sp
                'v_rel_mag': Relative speed to air [m/s]
        """
        # Gravity vector in global frame (Z is up)
        f_grav = np.array([0.0, 0.0, -BALL_MASS * STANDARD_GRAVITY])
        
        # Relative velocity to air
        v_rel = vel - self.wind_velocity
        v_rel_mag = float(np.linalg.norm(v_rel))
        omega_mag = float(np.linalg.norm(omega))
        
        # Default zero aero forces if ball is stationary
        if v_rel_mag < 1e-4:
            f_drag = np.zeros(3)
            f_magnus = np.zeros(3)
            cd = 0.45
            cl = 0.0
            reynolds = 0.0
            sp = 0.0
            tau_aero = np.zeros(3)
            return {
                'f_total': f_grav,
                'f_grav': f_grav,
                'f_drag': f_drag,
                'f_magnus': f_magnus,
                'torque_aero': tau_aero,
                'cd': cd,
                'cl': cl,
                'reynolds': reynolds,
                'spin_param': sp,
                'v_rel_mag': v_rel_mag
            }
            
        # Reynolds number Re = (rho * v * D) / mu
        reynolds = (self.rho * v_rel_mag * BALL_DIAMETER) / self.mu
        
        # Non-dimensional spin parameter Sp = (R * omega) / v
        sp = (BALL_RADIUS * omega_mag) / v_rel_mag
        
        # Drag calculation
        if self.enable_drag:
            cd = calculate_drag_coefficient(reynolds, sp)
            f_drag_mag = 0.5 * self.rho * BALL_AREA * cd * (v_rel_mag ** 2)
            f_drag = -f_drag_mag * (v_rel / v_rel_mag)
        else:
            cd = 0.0
            f_drag = np.zeros(3)
            
        # Magnus lift calculation
        # Direction of Magnus force: omega x v_rel
        if self.enable_magnus and omega_mag > 1e-4:
            cl = calculate_lift_coefficient(sp)
            cross_prod = np.cross(omega, v_rel)
            cross_mag = float(np.linalg.norm(cross_prod))
            if cross_mag > 1e-7:
                magnus_dir = cross_prod / cross_mag
                f_magnus_mag = 0.5 * self.rho * BALL_AREA * cl * (v_rel_mag ** 2)
                f_magnus = f_magnus_mag * magnus_dir
            else:
                f_magnus = np.zeros(3)
        else:
            cl = 0.0
            f_magnus = np.zeros(3)
            
        # Aerodynamic torque calculation
        if self.enable_spin_decay:
            tau_aero = calculate_spin_damping_torque(omega, v_rel_mag, self.rho, self.mu)
        else:
            tau_aero = np.zeros(3)
            
        f_total = f_grav + f_drag + f_magnus
        
        return {
            'f_total': f_total,
            'f_grav': f_grav,
            'f_drag': f_drag,
            'f_magnus': f_magnus,
            'torque_aero': tau_aero,
            'cd': cd,
            'cl': cl,
            'reynolds': reynolds,
            'spin_param': sp,
            'v_rel_mag': v_rel_mag
        }
