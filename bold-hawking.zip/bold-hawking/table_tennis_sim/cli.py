"""
Command-line interface and benchmark analysis for Table Tennis Aerodynamic Simulation.
"""

import sys
import json
import argparse
import numpy as np
from typing import Dict, Any

try:
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
except Exception:
    pass

from .constants import BALL_MASS, STANDARD_GRAVITY
from .aerodynamics import AerodynamicModel
from .simulator import TableTennisSimulator, SimulationResult
from .presets import STROKE_PRESETS, rpm_to_rad_s


def format_vector(v: np.ndarray, decimals: int = 2) -> str:
    return f"[{v[0]:.{decimals}f}, {v[1]:.{decimals}f}, {v[2]:.{decimals}f}]"


def print_comparison_table(results: Dict[str, SimulationResult]):
    """Prints a comparison table across different physics configurations."""
    print("\n" + "=" * 90)
    print(f"{'Конфигурация':<22} | {'Время (с)':<9} | {'Апекс Z (м)':<11} | {'Отскок X (м)':<12} | {'Попадание':<10} | {'F_M / F_g':<9}")
    print("-" * 90)
    
    fg_mag = BALL_MASS * STANDARD_GRAVITY
    
    for key, res in results.items():
        flight_t = f"{res.flight_time:.3f}"
        apex_z = f"{res.apex_point.pos[2]:.3f}" if res.apex_point else "N/A"
        
        if res.landing_spot is not None:
            landing_x = f"{res.landing_spot[0]:+.3f}"
            in_bounds = "Да (Стол)" if res.bounce_count_table > 0 else "Нет"
        else:
            landing_x = "Мимо стола"
            in_bounds = "Аут"
            
        p0 = res.trajectory[0] if res.trajectory else None
        if p0:
            fm_ratio = np.linalg.norm(p0.f_magnus) / fg_mag
            fm_str = f"{fm_ratio:.2f}x"
        else:
            fm_str = "-"
            
        print(f"{res.name:<22} | {flight_t:<9} | {apex_z:<11} | {landing_x:<12} | {in_bounds:<10} | {fm_str:<9}")
    print("=" * 90 + "\n")


def print_trajectory_breakdown(res: SimulationResult):
    """Prints detailed telemetry for key milestones in the flight."""
    print(f"\nДетальная телеметрия удара: {res.name}")
    print("-" * 80)
    if not res.trajectory:
        print("Траектория пуста.")
        return
        
    p_start = res.trajectory[0]
    p_apex = res.apex_point
    p_end = res.trajectory[-1]
    
    fg = BALL_MASS * STANDARD_GRAVITY
    
    print(f" • Начальные параметры:")
    print(f"   Позиция: {format_vector(p_start.pos, 3)} м")
    print(f"   Скорость: {p_start.speed:.1f} м/с ({p_start.speed * 3.6:.1f} км/ч) {format_vector(p_start.vel, 2)}")
    print(f"   Вращение: {p_start.rpm:.0f} RPM ({np.linalg.norm(p_start.omega):.1f} рад/с)")
    print(f"   Число Рейнольдса (Re): {p_start.reynolds:.0f}")
    print(f"   Спин-параметр (Sp = R*w/v): {p_start.spin_param:.3f}")
    print(f"   Лобовое сопротивление F_D: {np.linalg.norm(p_start.f_drag):.4f} Н ({np.linalg.norm(p_start.f_drag)/fg:.2f} от веса мяча)")
    print(f"   Сила Магнуса F_M: {np.linalg.norm(p_start.f_magnus):.4f} Н ({np.linalg.norm(p_start.f_magnus)/fg:.2f} от веса мяча)")
    print(f"   Коэффициенты: Cd = {p_start.cd:.3f}, Cl = {p_start.cl:.3f}")
    
    if p_apex:
        print(f"\n • Точка наивысшего подъема (Апекс):")
        print(f"   Время: t = {p_apex.t:.3f} с")
        print(f"   Координаты: {format_vector(p_apex.pos, 3)} м (Высота Z = {p_apex.pos[2]:.3f} м)")
        print(f"   Скорость в апексе: {p_apex.speed:.1f} м/с (Падение скорости на {(1 - p_apex.speed/p_start.speed)*100:.1f}%)")
        
    print(f"\n • События столкновений ({len(res.events)}):")
    for idx, ev in enumerate(res.events, 1):
        v_in_mag = np.linalg.norm(ev.vel_before)
        v_out_mag = np.linalg.norm(ev.vel_after)
        rpm_in = np.linalg.norm(ev.omega_before) * 60 / (2 * np.pi)
        rpm_out = np.linalg.norm(ev.omega_after) * 60 / (2 * np.pi)
        print(f"   [{idx}] t = {ev.time:.3f} с | {ev.event_type} ({ev.details})")
        print(f"       Координата: {format_vector(ev.position, 3)} м")
        print(f"       Скорость: {v_in_mag:.1f} м/с -> {v_out_mag:.1f} м/с | Вращение: {rpm_in:.0f} RPM -> {rpm_out:.0f} RPM")


def run_single_preset(preset_key: str, export_json: str = None) -> SimulationResult:
    if preset_key not in STROKE_PRESETS:
        raise ValueError(f"Unknown preset '{preset_key}'. Choose from: {list(STROKE_PRESETS.keys())}")
        
    preset = STROKE_PRESETS[preset_key]
    sim = TableTennisSimulator(dt=0.0005)
    
    res = sim.run_simulation(
        init_pos=preset['pos'],
        init_vel=preset['vel'],
        init_omega=preset['omega'],
        name=preset['title']
    )
    
    print(f"\n=======================================================")
    print(f"  {preset['title']}")
    print(f"=======================================================")
    print(f"{preset['description']}")
    
    print_trajectory_breakdown(res)
    
    if export_json:
        with open(export_json, 'w', encoding='utf-8') as f:
            json.dump(res.to_dict(), f, indent=2, ensure_ascii=False)
        print(f"\nДанные сохранены в файл: {export_json}")
        
    return res


def run_physics_comparison(preset_key: str = 'topspin_loop', export_json: str = None):
    preset = STROKE_PRESETS[preset_key]
    pos = preset['pos']
    vel = preset['vel']
    omega = preset['omega']
    
    # 1. Realistic: Magnus + Drag + Spin Damping
    model_full = AerodynamicModel(enable_drag=True, enable_magnus=True, enable_spin_decay=True)
    sim_full = TableTennisSimulator(aero_model=model_full, dt=0.0005)
    res_full = sim_full.run_simulation(pos, vel, omega, name="Реалистичная аэродинамика")
    
    # 2. Drag Only: No Magnus effect
    model_drag_only = AerodynamicModel(enable_drag=True, enable_magnus=False, enable_spin_decay=False)
    sim_drag_only = TableTennisSimulator(aero_model=model_drag_only, dt=0.0005)
    res_drag_only = sim_drag_only.run_simulation(pos, vel, omega, name="Только лобовое сопротивление")
    
    # 3. Vacuum: No air at all (Pure Ballistics)
    model_vacuum = AerodynamicModel(enable_drag=False, enable_magnus=False, enable_spin_decay=False)
    sim_vacuum = TableTennisSimulator(aero_model=model_vacuum, dt=0.0005)
    res_vacuum = sim_vacuum.run_simulation(pos, vel, omega, name="Вакуум (Баллистика)")
    
    results = {
        'full': res_full,
        'drag_only': res_drag_only,
        'vacuum': res_vacuum
    }
    
    print(f"\nСравнение физических моделей для удара: {preset['title']}")
    print_comparison_table(results)
    
    if export_json:
        payload = {k: v.to_dict() for k, v in results.items()}
        with open(export_json, 'w', encoding='utf-8') as f:
            json.dump(payload, f, indent=2, ensure_ascii=False)
        print(f"Данные сравнения сохранены в: {export_json}")
        
    return results


def main():
    parser = argparse.ArgumentParser(description="Аэродинамический симулятор настольного тенниса")
    parser.add_argument('--preset', type=str, default='topspin_loop', choices=list(STROKE_PRESETS.keys()),
                        help="Пресет удара для симуляции")
    parser.add_argument('--compare', action='store_true',
                        help="Запустить сравнение (Реальная аэродинамика vs Только Drag vs Вакуум)")
    parser.add_argument('--export', type=str, default=None,
                        help="Путь к JSON для экспорта результатов")
    parser.add_argument('--list', action='store_true',
                        help="Список всех доступных пресетов")
    args = parser.parse_args()
    
    if args.list:
        print("\nДоступные пресеты ударов:")
        for k, v in STROKE_PRESETS.items():
            print(f" - {k:<15} : {v['title']}")
        return
        
    if args.compare:
        run_physics_comparison(args.preset, export_json=args.export)
    else:
        run_single_preset(args.preset, export_json=args.export)


if __name__ == '__main__':
    main()
