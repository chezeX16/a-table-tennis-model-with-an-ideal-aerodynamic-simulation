"""
ITTF Regulation Constants and Physical Parameters for Table Tennis Aerodynamic Simulation.
References:
- ITTF Handbook (Equipment Regulations)
- NASA Technical Reports on Sphere Aerodynamics
- Cross, R. (2011). "Bounce of an elastic sphere with spin"
- Bearman, P. W., & Harvey, J. K. (1976). "Golf ball aerodynamics"
- Nakagawa et al. (2016). "Aerodynamic characteristics of table tennis balls"
"""

import math

# ==============================================================================
# BALL PROPERTIES (ITTF 40+ Polyball Standard)
# ==============================================================================
BALL_MASS = 0.00270            # Mass in kg (2.70 grams, ITTF: 2.67g - 2.77g)
BALL_DIAMETER = 0.0400         # Diameter in meters (40.0 mm, ITTF: 40.0mm - 40.6mm)
BALL_RADIUS = BALL_DIAMETER / 2.0  # Radius = 0.020 m
BALL_AREA = math.pi * (BALL_RADIUS ** 2)  # Cross-sectional area: ~1.2566e-3 m^2
BALL_VOLUME = (4.0 / 3.0) * math.pi * (BALL_RADIUS ** 3)

# Moment of inertia for a thin hollow spherical shell: I = (2/3) * m * R^2
# Plastic table tennis balls have wall thickness ~0.4 - 0.5 mm.
BALL_INERTIA = (2.0 / 3.0) * BALL_MASS * (BALL_RADIUS ** 2)  # ~7.2e-7 kg*m^2

# ==============================================================================
# TABLE & NET GEOMETRY (ITTF Regulation)
# System coordinates:
# Origin (0, 0, 0) is located at the center of the table surface.
# X-axis: Long axis of table (-1.37 m to +1.37 m, Server at -X, Receiver at +X)
# Y-axis: Width axis of table (-0.7625 m to +0.7625 m)
# Z-axis: Vertical axis (Z = 0 is table surface, Z > 0 is above table)
# Floor is at Z = -0.76 m.
# ==============================================================================
TABLE_LENGTH = 2.74            # meters (9 ft)
TABLE_WIDTH = 1.525            # meters (5 ft)
TABLE_HEIGHT_ABOVE_FLOOR = 0.76 # meters (2.5 ft)

TABLE_X_MIN = -TABLE_LENGTH / 2.0  # -1.37 m
TABLE_X_MAX = TABLE_LENGTH / 2.0   # +1.37 m
TABLE_Y_MIN = -TABLE_WIDTH / 2.0   # -0.7625 m
TABLE_Y_MAX = TABLE_WIDTH / 2.0    # +0.7625 m
TABLE_Z = 0.0                      # Table top surface level in simulation coords

# Net: Stretched across X = 0 from Y = -0.915 to +0.915
# ITTF net height: 15.25 cm (0.1525 m), posts extend 15.25 cm beyond side lines
NET_HEIGHT = 0.1525            # 15.25 cm
NET_OVERHANG = 0.1525          # Extends 15.25 cm beyond table width on both sides
NET_Y_MIN = -(TABLE_WIDTH / 2.0 + NET_OVERHANG)  # -0.915 m
NET_Y_MAX = +(TABLE_WIDTH / 2.0 + NET_OVERHANG)  # +0.915 m
NET_THICKNESS = 0.005          # 5 mm collision thickness

# ==============================================================================
# TABLE IMPACT DYNAMICS
# ==============================================================================
# Coefficient of restitution (COR): ITTF standard drop test (drop from 30.5 cm
# must rebound to 24.0 - 26.0 cm => e = sqrt(25/30.5) ~ 0.905)
TABLE_COR_NORMAL = 0.915

# Dynamic friction coefficient between celluloid/poly ball and lacquered table wood
TABLE_FRICTION_MU = 0.23

# Net restitution and damping
NET_COR = 0.20
NET_FRICTION = 0.50

# ==============================================================================
# STANDARD ATMOSPHERIC CONSTANTS
# ==============================================================================
STANDARD_GRAVITY = 9.80665     # m/s^2 (downward: -Z)
STANDARD_PRESSURE = 101325.0   # Pa (1 atm)
STANDARD_TEMP_C = 20.0         # degrees Celsius
R_DRY_AIR = 287.058            # J / (kg * K) - gas constant for dry air
R_VAPOR = 461.495              # J / (kg * K) - gas constant for water vapor

# Sutherland's law constants for air dynamic viscosity
SUTHERLAND_T0 = 273.15         # K
SUTHERLAND_MU0 = 1.716e-5      # Pa * s
SUTHERLAND_S = 110.4           # K
