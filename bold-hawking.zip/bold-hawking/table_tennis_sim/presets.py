"""
Preset table tennis strokes for physics simulations and comparisons.

Each preset defines:
- Initial position [x, y, z] in meters (relative to table center at Z=0)
- Initial velocity [vx, vy, vz] in m/s
- Initial spin [wx, wy, wz] in rad/s (using right-hand convention)
- Description of the stroke and its aerodynamic characteristics
"""

import math
import numpy as np
from typing import Dict, Any


def rpm_to_rad_s(rpm: float) -> float:
    return rpm * (2.0 * math.pi / 60.0)


def rev_s_to_rad_s(rev_s: float) -> float:
    return rev_s * (2.0 * math.pi)


STROKE_PRESETS: Dict[str, Dict[str, Any]] = {
    'topspin_loop': {
        'title': 'Топ-спин петля (Heavy Topspin Loop)',
        'description': (
            'Мощный атакующий удар с сильным верхним вращением (~6600 RPM). '
            'Эффект Магнуса направлен вниз, прижимая мяч к столу ("нырок") на скорости 19 м/с. '
            'Без Магнуса мяч улетел бы на 1.5 метра за пределы стола!'
        ),
        'pos': np.array([-1.50, -0.20, 0.25]),
        'vel': np.array([19.0, 0.40, 2.30]),
        'omega': np.array([0.0, rev_s_to_rad_s(110.0), 0.0]),  # +wy = topspin (dives down)
    },
    'backspin_chop': {
        'title': 'Защитная подрезка / Запил (Heavy Backspin Chop)',
        'description': (
            'Классический защитный запил из средней зоны с нижним вращением (~6000 RPM). '
            'Сила Магнуса направлена вверх, компенсируя гравитацию — мяч буквально парит над столом '
            'по пологой траектории, а при отскоке резко тормозит и стелется низко.'
        ),
        'pos': np.array([-1.80, 0.10, 0.20]),
        'vel': np.array([12.5, -0.20, 1.60]),
        'omega': np.array([0.0, rev_s_to_rad_s(-95.0), 0.0]),  # -wy = backspin (lifts up)
    },
    'ghost_serve': {
        'title': 'Призрачная подача Ма Линя (Ghost Serve / Backspin Return)',
        'description': (
            'Легендарная подача с запредельным нижним вращением (~7800 RPM) и малой поступательной скоростью. '
            'Мяч делает отскок на половине соперника, но из-за чудовищного момента трения '
            'продольная скорость меняет знак, и мяч прыгает назад в сетку!'
        ),
        'pos': np.array([-0.90, -0.30, 0.22]),
        'vel': np.array([3.4, 0.05, 1.45]),
        'omega': np.array([0.0, rev_s_to_rad_s(-130.0), 0.0]),
    },
    'banana_flick': {
        'title': 'Банана-флик / Чикита (Sidespin + Topspin Hook)',
        'description': (
            'Современный кистевой скрут со стола с сильным левым боковым и верхним вращением. '
            'Боковая сила Магнуса изгибает траекторию по дуге вокруг сетки, '
            'а при касании стола мяч совершает резкий боковой скачок в угол соперника.'
        ),
        'pos': np.array([-0.65, 0.25, 0.18]),
        'vel': np.array([11.8, -1.8, 1.40]),
        'omega': np.array([0.0, rev_s_to_rad_s(60.0), rev_s_to_rad_s(85.0)]),  # Top + Side
    },
    'flat_smash': {
        'title': 'Плоский смэш (Flat Power Smash)',
        'description': (
            'Убойный завершающий удар без вращения со скоростью 32 м/с (115 км/ч). '
            'Чистая доминанта аэродинамического лобового сопротивления (Re ~ 85 000). '
            'Сила сопротивления воздуха достигает 0.36 Н — это в 13.5 раз превышает вес самого мяча!'
        ),
        'pos': np.array([-1.40, -0.15, 0.65]),
        'vel': np.array([31.0, 0.20, -1.80]),
        'omega': np.array([0.0, rev_s_to_rad_s(8.0), 0.0]),  # Almost zero spin
    },
    'high_lob': {
        'title': 'Защитная высокая свеча (High Defensive Lob)',
        'description': (
            'Спасительная высокая свеча из дальней зоны (3 метра от стола) под углом 55 градусов. '
            'Мяч взлетает на высоту 3.4 метра, теряет скорость в апексе под действием сопротивления, '
            'круто падает вертикально и яростно отскакивает от стола.'
        ),
        'pos': np.array([-2.80, 0.30, 0.15]),
        'vel': np.array([12.5, -0.40, 7.80]),
        'omega': np.array([0.0, rev_s_to_rad_s(65.0), rev_s_to_rad_s(20.0)]),
    }
}
