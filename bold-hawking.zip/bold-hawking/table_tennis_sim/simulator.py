"""
Runge-Kutta 4th Order (RK4) Continuous Integrator for Table Tennis Aerodynamic Trajectories.
"""

import math
import numpy as np
from typing import List, Dict, Any, Optional
from .constants import (
    BALL_MASS, BALL_RADIUS, BALL_INERTIA,
    TABLE_Z, TABLE_HEIGHT_ABOVE_FLOOR,
    TABLE_X_MIN, TABLE_X_MAX, TABLE_Y_MIN, TABLE_Y_MAX
)
from .aerodynamics import AerodynamicModel
from .table_collision import (
    CollisionEvent, is_on_table_surface, which_court,
    resolve_table_bounce, check_net_collision, resolve_net_collision
)


class TrajectoryPoint:
    def __init__(self, t: float, pos: np.ndarray, vel: np.ndarray, omega: np.ndarray,
                 f_drag: np.ndarray, f_magnus: np.ndarray, f_grav: np.ndarray,
                 cd: float, cl: float, reynolds: float, spin_param: float):
        self.t = float(t)
        self.pos = pos.copy()
        self.vel = vel.copy()
        self.omega = omega.copy()
        self.speed = float(np.linalg.norm(vel))
        self.rpm = float(np.linalg.norm(omega) * (60.0 / (2.0 * math.pi)))
        
        self.f_drag = f_drag.copy()
        self.f_magnus = f_magnus.copy()
        self.f_grav = f_grav.copy()
        self.f_total = self.f_drag + self.f_magnus + self.f_grav
        
        self.cd = float(cd)
        self.cl = float(cl)
        self.reynolds = float(reynolds)
        self.spin_param = float(spin_param)

    def to_dict(self) -> Dict[str, Any]:
        return {
            't': round(self.t, 5),
            'x': round(float(self.pos[0]), 5),
            'y': round(float(self.pos[1]), 5),
            'z': round(float(self.pos[2]), 5),
            'vx': round(float(self.vel[0]), 4),
            'vy': round(float(self.vel[1]), 4),
            'vz': round(float(self.vel[2]), 4),
            'speed': round(self.speed, 3),
            'wx': round(float(self.omega[0]), 3),
            'wy': round(float(self.omega[1]), 3),
            'wz': round(float(self.omega[2]), 3),
            'rpm': round(self.rpm, 1),
            'f_drag_x': round(float(self.f_drag[0]), 5),
            'f_drag_y': round(float(self.f_drag[1]), 5),
            'f_drag_z': round(float(self.f_drag[2]), 5),
            'f_magnus_x': round(float(self.f_magnus[0]), 5),
            'f_magnus_y': round(float(self.f_magnus[1]), 5),
            'f_magnus_z': round(float(self.f_magnus[2]), 5),
            'cd': round(self.cd, 4),
            'cl': round(self.cl, 4),
            'reynolds': round(self.reynolds, 1),
            'spin_param': round(self.spin_param, 4)
        }


class SimulationResult:
    def __init__(self, name: str, aero_model: AerodynamicModel):
        self.name = name
        self.aero_model = aero_model
        self.trajectory: List[TrajectoryPoint] = []
        self.events: List[CollisionEvent] = []
        self.apex_point: Optional[TrajectoryPoint] = None
        self.flight_time: float = 0.0
        self.net_cleared: bool = False
        self.landing_spot: Optional[np.ndarray] = None
        self.bounce_count_table: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'flight_time': round(self.flight_time, 4),
            'bounce_count_table': self.bounce_count_table,
            'net_cleared': self.net_cleared,
            'landing_spot': self.landing_spot.tolist() if self.landing_spot is not None else None,
            'apex_z': round(float(self.apex_point.pos[2]), 4) if self.apex_point else None,
            'events': [e.to_dict() for e in self.events],
            'points': [p.to_dict() for p in self.trajectory]
        }


class TableTennisSimulator:
    def __init__(self, aero_model: Optional[AerodynamicModel] = None, dt: float = 0.001):
        """
        Initializes the simulator.
        
        Args:
            aero_model: AerodynamicModel instance (defaults to standard sea level atmosphere)
            dt: Simulation time step in seconds (e.g. 0.001s = 1ms, recommended 0.0005 - 0.001s)
        """
        self.aero_model = aero_model if aero_model is not None else AerodynamicModel()
        self.dt = dt
        self.floor_z = -TABLE_HEIGHT_ABOVE_FLOOR + BALL_RADIUS  # -0.74m

    def _derivatives(self, pos: np.ndarray, vel: np.ndarray, omega: np.ndarray):
        """
        Calculates d/dt [r, v, omega]
        dr/dt = v
        dv/dt = F_total / m
        domega/dt = tau_aero / I
        """
        forces = self.aero_model.evaluate_forces(vel, omega)
        acc = forces['f_total'] / BALL_MASS
        alpha = forces['torque_aero'] / BALL_INERTIA
        return vel, acc, alpha, forces

    def run_simulation(self,
                       init_pos: np.ndarray,
                       init_vel: np.ndarray,
                       init_omega: np.ndarray,
                       max_time: float = 2.5,
                       name: str = "Trajectory") -> SimulationResult:
        """
        Executes Runge-Kutta 4th order numerical integration until termination condition.
        
        Args:
            init_pos: Starting position [x, y, z] in meters
            init_vel: Starting velocity [vx, vy, vz] in m/s
            init_omega: Starting angular velocity [wx, wy, wz] in rad/s
            max_time: Maximum simulation duration in seconds
            name: Description label for this run
            
        Returns:
            SimulationResult object containing trajectory history and events
        """
        pos = np.asarray(init_pos, dtype=float).copy()
        vel = np.asarray(init_vel, dtype=float).copy()
        omega = np.asarray(init_omega, dtype=float).copy()
        
        result = SimulationResult(name, self.aero_model)
        
        t = 0.0
        dt = self.dt
        
        # Initial evaluation
        _, _, _, initial_forces = self._derivatives(pos, vel, omega)
        p0 = TrajectoryPoint(
            t, pos, vel, omega,
            initial_forces['f_drag'], initial_forces['f_magnus'], initial_forces['f_grav'],
            initial_forces['cd'], initial_forces['cl'],
            initial_forces['reynolds'], initial_forces['spin_param']
        )
        result.trajectory.append(p0)
        result.apex_point = p0
        
        max_bounces = 6
        bounces = 0
        has_cleared_net_plane = (pos[0] >= 0.0)
        
        while t < max_time and bounces < max_bounces:
            # 1. RK4 Integration step
            k1_v, k1_a, k1_alpha, forces_1 = self._derivatives(pos, vel, omega)
            
            pos_k2 = pos + 0.5 * dt * k1_v
            vel_k2 = vel + 0.5 * dt * k1_a
            omega_k2 = omega + 0.5 * dt * k1_alpha
            k2_v, k2_a, k2_alpha, _ = self._derivatives(pos_k2, vel_k2, omega_k2)
            
            pos_k3 = pos + 0.5 * dt * k2_v
            vel_k3 = vel + 0.5 * dt * k2_a
            omega_k3 = omega + 0.5 * dt * k2_alpha
            k3_v, k3_a, k3_alpha, _ = self._derivatives(pos_k3, vel_k3, omega_k3)
            
            pos_k4 = pos + dt * k3_v
            vel_k4 = vel + dt * k3_a
            omega_k4 = omega + dt * k3_alpha
            k4_v, k4_a, k4_alpha, _ = self._derivatives(pos_k4, vel_k4, omega_k4)
            
            next_pos = pos + (dt / 6.0) * (k1_v + 2.0 * k2_v + 2.0 * k3_v + k4_v)
            next_vel = vel + (dt / 6.0) * (k1_a + 2.0 * k2_a + 2.0 * k3_a + k4_a)
            next_omega = omega + (dt / 6.0) * (k1_alpha + 2.0 * k2_alpha + 2.0 * k3_alpha + k4_alpha)
            next_t = t + dt
            
            # 2. Net collision detection
            net_hit, net_t_frac, net_contact, is_cord = check_net_collision(pos, next_pos)
            if net_hit:
                event_t = t + net_t_frac * dt
                res_pos, res_vel, res_omega = resolve_net_collision(net_contact, next_vel, next_omega, is_cord)
                label = "NET_CORD_CLIP" if is_cord else "NET_COLLISION"
                ev = CollisionEvent(label, event_t, net_contact, vel, res_vel, omega, res_omega,
                                    f"Z_impact = {net_contact[2]:.3f} m")
                result.events.append(ev)
                pos = res_pos
                vel = res_vel
                omega = res_omega
                t = event_t
                continue
                
            # Track when ball safely passes X = 0 without hitting net
            if not has_cleared_net_plane and pos[0] < 0.0 and next_pos[0] >= 0.0:
                has_cleared_net_plane = True
                result.net_cleared = True
                
            # 3. Table bounce detection (Table top is at Z = 0; ball contact when Z <= BALL_RADIUS)
            if next_pos[2] <= BALL_RADIUS and vel[2] < 0:
                # Sub-step interpolation for exact table contact
                if abs(next_pos[2] - pos[2]) > 1e-8:
                    frac_bounce = (BALL_RADIUS - pos[2]) / (next_pos[2] - pos[2])
                    frac_bounce = max(0.0, min(1.0, frac_bounce))
                else:
                    frac_bounce = 0.5
                    
                impact_pos = pos + frac_bounce * (next_pos - pos)
                impact_vel = vel + frac_bounce * (next_vel - vel)
                impact_omega = omega + frac_bounce * (next_omega - omega)
                impact_t = t + frac_bounce * dt
                
                # Check if impact is within table horizontal boundaries
                if is_on_table_surface(impact_pos[0], impact_pos[1]):
                    court = which_court(impact_pos[0])
                    post_pos, post_vel, post_omega = resolve_table_bounce(impact_pos, impact_vel, impact_omega)
                    bounces += 1
                    result.bounce_count_table += 1
                    if result.landing_spot is None:
                        result.landing_spot = impact_pos.copy()
                        
                    ev = CollisionEvent(
                        'TABLE_BOUNCE', impact_t, impact_pos,
                        impact_vel, post_vel, impact_omega, post_omega,
                        f"Court: {court}, Bounce #{bounces}"
                    )
                    result.events.append(ev)
                    
                    pos = post_pos
                    vel = post_vel
                    omega = post_omega
                    t = impact_t
                    
                    # Record point immediately after bounce
                    _, _, _, post_forces = self._derivatives(pos, vel, omega)
                    pt = TrajectoryPoint(
                        t, pos, vel, omega,
                        post_forces['f_drag'], post_forces['f_magnus'], post_forces['f_grav'],
                        post_forces['cd'], post_forces['cl'],
                        post_forces['reynolds'], post_forces['spin_param']
                    )
                    result.trajectory.append(pt)
                    continue
                    
            # 4. Floor impact detection
            if next_pos[2] <= self.floor_z:
                frac_floor = (self.floor_z - pos[2]) / (next_pos[2] - pos[2] + 1e-9)
                floor_pos = pos + max(0.0, min(1.0, frac_floor)) * (next_pos - pos)
                ev = CollisionEvent(
                    'FLOOR_HIT', t + dt, floor_pos,
                    next_vel, np.zeros(3), next_omega, np.zeros(3),
                    "Ball struck the floor."
                )
                result.events.append(ev)
                break
                
            # Advance state
            pos = next_pos
            vel = next_vel
            omega = next_omega
            t = next_t
            
            # Evaluate telemetry point
            _, _, _, f_current = self._derivatives(pos, vel, omega)
            pt = TrajectoryPoint(
                t, pos, vel, omega,
                f_current['f_drag'], f_current['f_magnus'], f_current['f_grav'],
                f_current['cd'], f_current['cl'],
                f_current['reynolds'], f_current['spin_param']
            )
            result.trajectory.append(pt)
            
            if pt.pos[2] > result.apex_point.pos[2]:
                result.apex_point = pt
                
        result.flight_time = t
        return result
