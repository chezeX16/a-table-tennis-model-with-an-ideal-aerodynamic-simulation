"""
Table and Net Collision Mechanics for Table Tennis Aerodynamic Simulation.

Implements:
1. Exact ITTF Table boundaries (2.74m x 1.525m at Z = 0) and Net boundaries (H = 15.25cm).
2. Continuous Collision Detection (CCD) with sub-step root finding to prevent tunneling.
3. Cross (2011) Impact Dynamics:
   - Restitution in normal direction (e_n = 0.915)
   - Tangential friction impulse with slip-to-roll transition (Coulomb limit vs Grip impulse)
   - Angular momentum exchange: topspin accelerates forward, backspin brakes / reverses,
     sidespin produces lateral deflection upon bounce.
4. Net interaction model (net collision, net-cord deflection, or net absorption).
"""

import math
import numpy as np
from .constants import (
    BALL_RADIUS, BALL_MASS, BALL_INERTIA,
    TABLE_X_MIN, TABLE_X_MAX, TABLE_Y_MIN, TABLE_Y_MAX, TABLE_Z,
    TABLE_COR_NORMAL, TABLE_FRICTION_MU,
    NET_HEIGHT, NET_Y_MIN, NET_Y_MAX, NET_THICKNESS, NET_COR, NET_FRICTION
)


class CollisionEvent:
    def __init__(self, event_type: str, time: float, position: np.ndarray,
                 vel_before: np.ndarray, vel_after: np.ndarray,
                 omega_before: np.ndarray, omega_after: np.ndarray,
                 details: str = ""):
        self.event_type = event_type  # 'TABLE_BOUNCE', 'NET_HIT', 'FLOOR_HIT', 'OUT_OF_BOUNDS'
        self.time = time
        self.position = position.copy()
        self.vel_before = vel_before.copy()
        self.vel_after = vel_after.copy()
        self.omega_before = omega_before.copy()
        self.omega_after = omega_after.copy()
        self.details = details

    def to_dict(self):
        return {
            'event_type': self.event_type,
            'time': float(self.time),
            'position': self.position.tolist(),
            'vel_before': self.vel_before.tolist(),
            'vel_after': self.vel_after.tolist(),
            'omega_before': self.omega_before.tolist(),
            'omega_after': self.omega_after.tolist(),
            'details': self.details
        }


def is_on_table_surface(x: float, y: float) -> bool:
    """Checks whether horizontal coordinates fall within the ITTF table bounds."""
    return (TABLE_X_MIN <= x <= TABLE_X_MAX) and (TABLE_Y_MIN <= y <= TABLE_Y_MAX)


def which_court(x: float) -> str:
    """Returns 'SERVER' (X < 0), 'RECEIVER' (X > 0), or 'NET' (X == 0)."""
    if x < -0.01:
        return 'SERVER'
    elif x > 0.01:
        return 'RECEIVER'
    else:
        return 'NET'


def resolve_table_bounce(pos: np.ndarray,
                         vel: np.ndarray,
                         omega: np.ndarray,
                         cor_normal: float = TABLE_COR_NORMAL,
                         friction_mu: float = TABLE_FRICTION_MU):
    """
    Computes post-collision linear and angular velocities using the Cross impact model.
    
    Args:
        pos: Current ball position [x, y, z] (with z close to BALL_RADIUS)
        vel: Pre-collision velocity [vx, vy, vz] (vz < 0)
        omega: Pre-collision angular velocity [wx, wy, wz] in rad/s
        cor_normal: Coefficient of restitution (normal)
        friction_mu: Dynamic friction coefficient
        
    Returns:
        (new_pos, new_vel, new_omega)
    """
    new_pos = pos.copy()
    new_pos[2] = BALL_RADIUS  # Snap ball center to surface + radius
    
    # 1. Normal rebound
    vz_pre = vel[2]
    vz_post = -cor_normal * vz_pre
    
    # Normal impulse magnitude: J_z = m * (vz_post - vz_pre) = m * (1 + e) * |vz_pre|
    j_normal = BALL_MASS * (1.0 + cor_normal) * abs(vz_pre)
    
    # 2. Contact point relative tangential velocity:
    # r_c = (0, 0, -R)
    # v_cp = v_t + omega x r_c
    # omega x (0, 0, -R) = (-R * omega_y, R * omega_x, 0)
    v_cp_x = vel[0] - BALL_RADIUS * omega[1]
    v_cp_y = vel[1] + BALL_RADIUS * omega[0]
    v_cp = np.array([v_cp_x, v_cp_y])
    v_cp_mag = float(np.linalg.norm(v_cp))
    
    if v_cp_mag < 1e-6:
        # Pure rolling without slip
        j_tangent = np.zeros(2)
    else:
        u_cp = v_cp / v_cp_mag
        # Grip impulse needed to completely bring contact point slip to zero:
        # J_grip = (2/5) * m * v_cp
        j_grip_mag = (2.0 / 5.0) * BALL_MASS * v_cp_mag
        j_friction_limit = friction_mu * j_normal
        
        # Coulomb friction limit
        if j_grip_mag <= j_friction_limit:
            # Ball grips during impact! Pure rolling release
            j_tangent = j_grip_mag * u_cp
        else:
            # Ball slips throughout impact
            j_tangent = j_friction_limit * u_cp
            
    # Apply tangential impulse to linear velocity:
    # v_t_post = v_t_pre - J_t / m
    vx_post = vel[0] - (j_tangent[0] / BALL_MASS)
    vy_post = vel[1] - (j_tangent[1] / BALL_MASS)
    
    # Apply tangential impulse torque to angular velocity:
    # tau = r_c x J_t = (0, 0, -R) x (J_tx, J_ty, 0) = (R * J_ty, -R * J_tx, 0)
    # delta_omega = tau / I
    d_omega_x = (BALL_RADIUS * j_tangent[1]) / BALL_INERTIA
    d_omega_y = -(BALL_RADIUS * j_tangent[0]) / BALL_INERTIA
    
    omega_x_post = omega[0] + d_omega_x
    omega_y_post = omega[1] + d_omega_y
    # Vertical axis spin (gyro/corkscrew) experiences minor torsional contact damping
    omega_z_post = omega[2] * 0.92
    
    new_vel = np.array([vx_post, vy_post, vz_post])
    new_omega = np.array([omega_x_post, omega_y_post, omega_z_post])
    
    return new_pos, new_vel, new_omega


def check_net_collision(pos_pre: np.ndarray, pos_post: np.ndarray):
    """
    Checks if the trajectory segment between pos_pre and pos_post intersects the net plane (X = 0).
    
    The net is located at X = 0, spanning Y in [NET_Y_MIN, NET_Y_MAX], Z in [0, NET_HEIGHT].
    
    Returns:
        (hit_detected, hit_fraction, impact_point, is_net_cord)
    """
    x1, x2 = pos_pre[0], pos_post[0]
    
    # Does segment cross X = 0?
    if (x1 < -BALL_RADIUS and x2 < -BALL_RADIUS) or (x1 > BALL_RADIUS and x2 > BALL_RADIUS):
        return False, 0.0, None, False
        
    dx = x2 - x1
    if abs(dx) < 1e-9:
        return False, 0.0, None, False
        
    # Fraction t in [0, 1] where X crosses 0
    t = (0.0 - x1) / dx
    if not (0.0 <= t <= 1.0):
        return False, 0.0, None, False
        
    # Interpolated position at X = 0
    y_at_net = pos_pre[1] + t * (pos_post[1] - pos_pre[1])
    z_at_net = pos_pre[2] + t * (pos_post[2] - pos_pre[2])
    
    # Check if within net Y and Z boundaries
    if (NET_Y_MIN - BALL_RADIUS <= y_at_net <= NET_Y_MAX + BALL_RADIUS) and (-BALL_RADIUS <= z_at_net <= NET_HEIGHT + BALL_RADIUS):
        is_net_cord = (NET_HEIGHT - 0.015 <= z_at_net <= NET_HEIGHT + BALL_RADIUS)
        impact_point = np.array([0.0, y_at_net, z_at_net])
        return True, t, impact_point, is_net_cord
        
    return False, 0.0, None, False


def resolve_net_collision(pos: np.ndarray, vel: np.ndarray, omega: np.ndarray, is_net_cord: bool):
    """
    Resolves net collision.
    If hitting the flexible mesh: substantial energy absorption and rebound backwards or drop down.
    If clipping the net cord (top white tape): slight downward and forward deflection (let/cord roll).
    """
    new_pos = pos.copy()
    new_vel = vel.copy()
    new_omega = omega.copy()
    
    if is_net_cord:
        # Net cord clip: ball continues forward with slight deceleration and downward tilt
        new_vel[0] *= 0.75
        new_vel[1] *= 0.85
        new_vel[2] = -0.4 * abs(vel[2]) - 0.5  # deflected slightly down
        new_omega *= 0.70
    else:
        # Direct net hit: ball bounces off the cloth/mesh
        new_vel[0] = -NET_COR * vel[0]
        new_vel[1] *= 0.50
        new_vel[2] *= 0.40
        new_omega *= 0.40
        
    return new_pos, new_vel, new_omega
