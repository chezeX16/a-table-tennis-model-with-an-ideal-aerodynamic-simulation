"""
Physics and Aerodynamics Unit Tests for Table Tennis Simulator.
"""

import math
import unittest
import numpy as np

from table_tennis_sim.constants import (
    BALL_MASS, BALL_RADIUS, STANDARD_GRAVITY,
    TABLE_X_MIN, TABLE_X_MAX
)
from table_tennis_sim.aerodynamics import (
    calculate_air_density, calculate_dynamic_viscosity,
    calculate_drag_coefficient, calculate_lift_coefficient,
    AerodynamicModel
)
from table_tennis_sim.table_collision import (
    resolve_table_bounce, check_net_collision, is_on_table_surface
)
from table_tennis_sim.simulator import TableTennisSimulator


class TestTableTennisPhysics(unittest.TestCase):
    def test_atmosphere_physics(self):
        rho_cold_dry = calculate_air_density(temp_c=0.0, pressure_pa=101325, relative_humidity=0.0)
        rho_hot_humid = calculate_air_density(temp_c=35.0, pressure_pa=101325, relative_humidity=0.9)
        self.assertGreater(rho_cold_dry, rho_hot_humid)
        self.assertTrue(1.15 < rho_cold_dry < 1.35)
        self.assertTrue(1.05 < rho_hot_humid < 1.25)

    def test_magnus_force_direction(self):
        model = AerodynamicModel()
        vel_fwd = np.array([15.0, 0.0, 0.0])
        
        # 1. Topspin: +wy pushes DOWN (-Z)
        omega_top = np.array([0.0, 500.0, 0.0])
        forces_top = model.evaluate_forces(vel_fwd, omega_top)
        f_mag_top = forces_top['f_magnus']
        self.assertLess(f_mag_top[2], -0.01)
        self.assertAlmostEqual(f_mag_top[0], 0.0, places=4)
        self.assertAlmostEqual(f_mag_top[1], 0.0, places=4)
        
        # 2. Backspin: -wy pushes UP (+Z)
        omega_back = np.array([0.0, -500.0, 0.0])
        forces_back = model.evaluate_forces(vel_fwd, omega_back)
        f_mag_back = forces_back['f_magnus']
        self.assertGreater(f_mag_back[2], 0.01)
        
        # 3. Sidespin: +wz curves LEFT (+Y)
        omega_side = np.array([0.0, 0.0, 500.0])
        forces_side = model.evaluate_forces(vel_fwd, omega_side)
        f_mag_side = forces_side['f_magnus']
        self.assertGreater(f_mag_side[1], 0.01)

    def test_drag_force_opposes_motion(self):
        model = AerodynamicModel()
        vel = np.array([12.0, -5.0, 3.0])
        omega = np.zeros(3)
        forces = model.evaluate_forces(vel, omega)
        f_drag = forces['f_drag']
        
        # Drag must strictly oppose velocity
        dot = np.dot(f_drag, vel)
        self.assertLess(dot, 0.0)
        unit_vel = vel / np.linalg.norm(vel)
        unit_drag = f_drag / np.linalg.norm(f_drag)
        np.testing.assert_allclose(unit_drag, -unit_vel, atol=1e-5)

    def test_table_bounce_spin_coupling(self):
        pos = np.array([0.5, 0.0, BALL_RADIUS])
        vel = np.array([10.0, 0.0, -3.0])
        
        # Backspin: omega_y < 0 brakes forward velocity
        omega_backspin = np.array([0.0, -600.0, 0.0])
        _, vel_back_post, omega_back_post = resolve_table_bounce(pos, vel, omega_backspin)
        
        self.assertLess(vel_back_post[0], vel[0])
        self.assertGreater(vel_back_post[2], 0.0)
        self.assertAlmostEqual(vel_back_post[2], 0.915 * 3.0, places=2)

    def test_net_collision_detection(self):
        # Segment passing cleanly above net: z = 0.25m > net height (0.1525m)
        p1_over = np.array([-0.2, 0.0, 0.25])
        p2_over = np.array([0.2, 0.0, 0.25])
        hit_over, _, _, _ = check_net_collision(p1_over, p2_over)
        self.assertFalse(hit_over)
        
        # Segment directly hitting net: z = 0.08m < 0.1525m, crossing X=0
        p1_hit = np.array([-0.1, 0.0, 0.08])
        p2_hit = np.array([0.1, 0.0, 0.08])
        hit_net, t, contact, is_cord = check_net_collision(p1_hit, p2_hit)
        self.assertTrue(hit_net)
        self.assertAlmostEqual(contact[0], 0.0, places=4)
        self.assertFalse(is_cord)


if __name__ == '__main__':
    unittest.main()
